<div class="wrapper">

    <div class="main-panel">
        <?php echo $__env->make('layouts.navbars.navs.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div><?php /**PATH C:\laragon\www\comercialbcn\resources\views/layouts/page_templates/auth.blade.php ENDPATH**/ ?>