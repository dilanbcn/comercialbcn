<form id="frm_del_registro" method="POST" style="visibility: hidden;">
    <?php echo method_field('DELETE'); ?>
    <?php echo csrf_field(); ?>
</form><?php /**PATH C:\laragon\www\comercialbcn\resources\views/layouts/page_templates/form_delete.blade.php ENDPATH**/ ?>