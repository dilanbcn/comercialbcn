
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('layouts.page_templates.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h5 class="card-title mb-1">Comerciales</h5>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('user.create')); ?>" class="btn btn-sm btn-secondary btn-round"><i class="fas fa-plus"></i> Agregar</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table">
                        <table class="table table-striped" id="tablaComercialesIdex">
                            <thead class="text-primary text-center">
                                <th>Rut</th>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Correo</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $comerciales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($usuario->id_number); ?></td>
                                    <td class="text-left"><?php echo e($usuario->name); ?></td>
                                    <td class="text-left"><?php echo e($usuario->last_name); ?></td>
                                    <td><?php echo e($usuario->email); ?></td>
                                    <td><?php echo e(($usuario->activo) ? 'Activo' : 'Inactivo'); ?></td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Grupo Acciones">
                                            <a href="<?php echo e(route('user.edit', $usuario->id)); ?>" title="Editar" class="btn btn-xs btn-outline-secondary"><i class="fa fa-edit"></i></a>
                                            <a href="#" id="<?php echo e($usuario->id); ?>" title="Eliminar Comercial" class="btn btn-xs btn-outline-danger delRegistro" data-recurs="0" data-ruta="<?php echo e(route('user.destroy', $usuario->id)); ?>"><i class="fa fa-times"></i></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.page_templates.form_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
'class' => '',
'elementActive' => 'comerciales'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\comercialbcn\resources\views/pages/usuario/index.blade.php ENDPATH**/ ?>