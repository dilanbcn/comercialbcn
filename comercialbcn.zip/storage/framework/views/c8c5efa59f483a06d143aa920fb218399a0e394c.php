
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('layouts.page_templates.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h5 class="card-title mb-1">Detalle Comerciales</h5>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('principal')); ?>" class="btn btn-sm btn-danger btn-round">Regresar</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table">
                        <table class="table table-striped" id="tablaComercialesIdex">
                            <thead class="text-primary text-center">
                                <th>Comercial</th>
                                <th>Total Prospectos</th>
                                <th>Efctividad</th>
                                <th>Total Clientes</th>
                                <th>% Clientes Activos</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td class="text-left"><?php echo e($usuario->name . ' ' . $usuario->last_name); ?></td>
                                    <td><?php echo e($usuario->prospectos); ?></td>
                                    <td>
                                        <div class="progress"  style="height: 5px;width: 100%;">
                                            <div class="progress-bar <?php echo e($usuario->efect_color); ?>" role="progressbar" style="<?php echo e($usuario->width_efectividad); ?>" aria-valuenow="<?php echo e($usuario->efectividad); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <div style="padding-left: 1rm;"><?php echo e($usuario->efectividad . '%'); ?></div>
                                    </td>
                                    <td><?php echo e($usuario->clientes); ?></td>
                                    <td>
                                        <div class="chart" data-percent="<?php echo e($usuario->pct_activos); ?>">
                                            <span class="percent"><?php echo e($usuario->pct_activos . '%'); ?></span>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.page_templates.form_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
'class' => '',
'elementActive' => 'comerciales'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\comercialbcn\resources\views/pages/usuario/index-grafico.blade.php ENDPATH**/ ?>