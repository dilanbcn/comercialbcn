<input type="hidden" id="msg-data" data-estilo="<?php echo e(session('estilo') ? session('estilo') : 'success'); ?>" name="msg-data" data-titulo="<?php echo e(session('title')); ?>" value="<?php echo e(session('status')); ?>">

<?php /**PATH C:\laragon\www\comercialbcn\resources\views/layouts/page_templates/messages.blade.php ENDPATH**/ ?>