<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container">
        <?php if(session('error')): ?>
        <div class="row">
            <div class="col-md-6 ml-auto mr-auto">
                <div class="alert alert-danger alert-dismissible fade show">
                    <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                        <i class="nc-icon nc-simple-remove"></i>
                    </button>
                    <span> <?php echo e(session('error')); ?></span>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-6 ml-auto mr-auto login-form-2">
                <h3><?php echo e(__('Iniciar Sesión')); ?></h3>
                <form class="form" method="POST" action="<?php echo e(route('custom-login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input class="form-control <?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Usuario')); ?>" type="text" name="username" value="<?php echo e(old('username')); ?>" required autofocus>
                        <?php if($errors->has('username')): ?>
                        <span class="invalid-text" style="display: block;" role="alert">
                            <strong><?php echo e($errors->first('username')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="<?php echo e(__('Clave')); ?>" type="password" required>
                        <?php if($errors->has('password')): ?>
                        <span class="invalid-text" style="display: block;" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-outline-light btn-round mb-3"><?php echo e(__('Ingresar')); ?></button>
                    </div>
                </form>

            </div>

        </div>
        <div class="row">
            <div class="col-md-6 ml-auto mr-auto">
                <a href="<?php echo e(route('password.request')); ?>" class="btn btn-link">
                    <?php echo e(__('Olvidó su contraseña')); ?>

                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        graficos.checkFullPageBackgroundImage();
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'class' => 'login-page',
'backgroundImagePath' => 'img/bg/background.jpg'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\comercialbcn\resources\views/auth/login.blade.php ENDPATH**/ ?>