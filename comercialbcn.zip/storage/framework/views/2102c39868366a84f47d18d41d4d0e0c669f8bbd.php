<!--
=========================================================
 Paper Dashboard - v2.0.0
=========================================================

 Product Page: https://www.creative-tim.com/product/paper-dashboard
 Copyright 2019 Creative Tim (https://www.creative-tim.com)
 UPDIVISION (https://updivision.com)
 Licensed under MIT (https://github.com/creativetimofficial/paper-dashboard/blob/master/LICENSE)

 Coded by Creative Tim

=========================================================

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. -->



<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('paper/img/apple-icon.png')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('paper/img/favicon.png')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <!-- Extra details for Live View on GitHub Pages -->
    
    <title>
        <?php echo e(__('Comercial')); ?>

    </title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
        name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="<?php echo e(asset('paper/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('paper/css/paper-dashboard.css?v=2.0.0')); ?>" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="<?php echo e(asset('paper/css/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('paper/css/bootstrap4-toggle.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('paper/css/jquery-confirm.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('paper/css/bootstrap-select.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('paper/css/submit.css')); ?>" rel="stylesheet" />
    <!-- Data Tables -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('paper/css/datatables.min.css')); ?>"/>
    <!-- Toast -->
    <!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('paper/css/jquery.toast.min.css')); ?>"/> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('paper/css/toastr.min.css')); ?>"/>
    <!-- CharJs -->
    <link href="<?php echo e(asset('paper/css/chartjs/Chart.min.css')); ?>" rel="stylesheet" />
    
    <!-- Easy Pie Chart -->
    
</head>

<body class="<?php echo e($class); ?>">
    
    <?php if(auth()->guard()->check()): ?>
        <?php echo $__env->make('layouts.page_templates.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <?php if(auth()->guard()->guest()): ?>
        <?php echo $__env->make('layouts.page_templates.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('paper/js/core/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('paper/js/core/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('paper/js/core/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('paper/js/plugins/perfect-scrollbar.jquery.min.js')); ?>"></script>
    <!-- Chart JS -->
    <script src="<?php echo e(asset('paper/js/plugins/chartjs.min.js')); ?>"></script>
    <!--  Notifications Plugin    -->
    <script src="<?php echo e(asset('paper/js/plugins/bootstrap-notify.js')); ?>"></script>
    <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="<?php echo e(asset('paper/js/paper-dashboard.min.js?v=2.0.0')); ?>" type="text/javascript"></script>

    <script src="<?php echo e(asset('paper/js/plugins/bootstrap4-toggle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('paper/js/plugins/jquery-confirm.min.js')); ?>"></script>
    <script src="<?php echo e(asset('paper/js/comercial.js')); ?>"></script>
    <script src="<?php echo e(asset('paper/js/combos.js')); ?>"></script>
    <script src="<?php echo e(asset('paper/js/graficos.js')); ?>"></script>
    <script src="<?php echo e(asset('paper/js/submit.js')); ?>"></script>
    <script src="<?php echo e(asset('paper/js/plugins/bootstrap-select.min.js')); ?>"></script>
    <script src="https://kit.fontawesome.com/00c104946b.js" crossorigin="anonymous"></script>
    <!-- Data Tables -->
    <script type="text/javascript" src="<?php echo e(asset('paper/js/datatables.min.js')); ?>"></script>
    <!-- Toast -->
    <!-- <script type="text/javascript" src="<?php echo e(asset('paper/js/jquery.toast.min.js')); ?>"></script> -->
    <script type="text/javascript" src="<?php echo e(asset('paper/js/toastr.min.js')); ?>"></script>

    <!-- Chart Js -->
    <script src="<?php echo e(asset('paper/js/plugins/chartjs/Chart.js')); ?>"></script>

    <!-- Easy Pie Chart -->
    <script src="<?php echo e(asset('paper/js/plugins/easy-pie-chart/jquery.easypiechart.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\comercialbcn\resources\views/layouts/app.blade.php ENDPATH**/ ?>