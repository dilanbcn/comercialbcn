
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('layouts.page_templates.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col-4">
                            <h5 class="card-title mb-1">Clientes</h5>
                        </div>
                        <?php $__currentLoopData = $arrGrupo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-2 text-center font-weight-bold text-white p-2 <?php echo e($key == 'Activos' ? 'bg-info' : 'bg-danger'); ?>">
                            <span><?php echo e($key . ': ' . $estado); ?></span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('cliente.create')); ?>" class="btn btn-sm btn-secondary btn-round"><i class="fas fa-plus"></i> Agregar</a>
                        </div>

                    </div>
                </div>
                <div class="card-body">
                    <div class="table">
                        <table class="table table-striped" id="tablaComercialesIdex">
                            <thead class="text-primary text-center">
                                <th>Holding</th>
                                <th>Razón Social</th>
                                <th>Comercial</th>
                                <th>Tipo</th>
                                <th>Inicio Ciclo</th>
                                <th>Ciclo 8 Meses</th>
                                <th>Estado</th>
                                <th>Cant Proyectos</th>
                                <th>Acciones</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e(($cliente->padre != null) ? $cliente->padre->razon_social : ''); ?></td>
                                    <td class="text-left"><?php echo e($cliente->razon_social); ?></td>
                                    <td class="text-left"><?php echo e($cliente->user->name . ' ' . $cliente->user->last_name); ?></td>
                                    <td><span class="badge p-2 <?php echo e($cliente->tipoCliente->badge); ?>"><?php echo e($cliente->tipoCliente->nombre); ?></span></td>
                                    <td><?php echo e(($cliente->tipo_cliente_id == 1) ? date('d/m/Y', strtotime($cliente->inicio_ciclo)) : ''); ?></td>
                                    <td><?php echo e(($cliente->tipo_cliente_id == 1) ? $cliente->ciclo : ''); ?></td>
                                    <td><?php echo e(($cliente->activo) ? 'Activo' : 'Inactivo'); ?></td>
                                    <td><?php echo e($cliente->proyecto_count); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('proyecto.cliente-proyecto', $cliente->id)); ?>" title="Proyectos" class="btn btn-xs btn-outline-secondary"><i class="far fa-handshake"></i></a>
                                        <div class="btn-group" role="group" aria-label="Grupo Acciones">
                                            <a href="<?php echo e(route('cliente.edit', $cliente->id)); ?>" title="Editar" class="btn btn-xs btn-outline-secondary"><i class="fa fa-edit"></i></a>
                                            <a href="#" id="<?php echo e($cliente->id); ?>" title="Eliminar Cliente" class="btn btn-xs btn-outline-danger delRegistro" data-recurs="0" data-ruta="<?php echo e(route('cliente.destroy', $cliente->id)); ?>"><i class="fa fa-times"></i></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.page_templates.form_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
'class' => '',
'elementActive' => 'clientes'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\comercialbcn\resources\views/pages/cliente/index.blade.php ENDPATH**/ ?>