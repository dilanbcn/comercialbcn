<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container">
        <div class="row">
            <div class="col-md-6 ml-auto mr-auto login-form-2">
                <h3><?php echo e(__('Reestablecer Clave')); ?></h3>
                <form class="form" method="POST" action="<?php echo e(route('password.email')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Correo')); ?>" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                        <?php if($errors->has('email')): ?>
                        <span class="invalid-text" style="display: block;" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-outline-light btn-round mb-3"><?php echo e(__('Reestablecer')); ?></button>
                        <a role="button" href="<?php echo e(url()->previous()); ?>" class="btn btn-outline-light btn-round mb-3"><?php echo e(__('Cancelar')); ?></a>
                    </div>
                </form>
            </div>
        </div>
           
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            demo.checkFullPageBackgroundImage();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
    'class' => 'login-page',
    'backgroundImagePath' => 'img/bg/fabio-mangione.jpg'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\comercialbcn\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>