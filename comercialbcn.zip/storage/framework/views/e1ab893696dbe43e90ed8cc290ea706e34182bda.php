
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.page_templates.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content" id="msg-modal" data-valor="<?php echo e(($errors->any()) ? 1 : 0); ?>" data-nombre="add_proyecto_cliente" data-update="update_proyecto_cliente">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h5 class="card-title mb-1"><?php echo e(__('Cliente')); ?></h5>
                        </div>
                        <div class="col-4 text-right">
                            <a role="button" href="<?php echo e(route('cliente.index')); ?>" class="btn btn-sm btn-danger btn-round"><?php echo e(__('Regresar')); ?></a>
                        </div>

                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label><?php echo e(__('Razón Social')); ?></label>
                                <h5><?php echo e($cliente->razon_social); ?></h5>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label><?php echo e(__('Comercial')); ?></label>
                                <h5><?php echo e($cliente->user->name . ' ' . $cliente->user->last_name); ?></h5>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label><?php echo e(__('Tipo Cliente')); ?></label>
                                <h5><?php echo e($cliente->tipoCliente->nombre); ?></h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h5 class="card-title mb-1">Proyectos</h5>
                        </div>
                        <div class="col-4 text-right">
                            <a href="#" class="btn btn-sm btn-secondary btn-round" id="btnModalProy"><i class="fas fa-plus"></i> Agregar</a>
                        </div>

                    </div>
                </div>
                <div class="card-body">
                    <div class="table">
                        <table class="table table-striped" id="tablaComercialesIdex">
                            <thead class="text-primary text-center">
                                <th>Nombre</th>
                                <th>Fecha Cierre</th>
                                <th>Cant. Facturas</th>
                                <th>Total Facturas</th>
                                <th>Acciones</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td class="text-left"><?php echo e($proyecto->nombre); ?></td>
                                    <td><?php echo e(date('d/m/Y', strtotime($proyecto->fecha_cierre))); ?></td>
                                    <td><?php echo e(count($proyecto->proyectoFacturas)); ?></td>
                                    <td><?php echo e(number_format($proyecto->sum_facturas, 2, '.', '.')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('factura.proyecto-factura', $proyecto->id)); ?>" title="Facturación" class="btn btn-xs btn-outline-secondary"><i class="fas fa-file-invoice-dollar"></i></a>
                                        <div class="btn-group" role="group" aria-label="Grupo Acciones">
                                            <a href="#" title="Editar" class="btn btn-xs btn-outline-secondary btnProyEdit" data-editar="<?php echo e(route('proyecto.edit', $proyecto->id)); ?>" data-actualizar="<?php echo e(route('proyecto.update', $proyecto->id)); ?>"><i class="fa fa-edit"></i></a>
                                            <a href="#" id="<?php echo e($proyecto->id); ?>" title="Eliminar Proyecto" class="btn btn-xs btn-outline-danger delRegistro" data-recurs="1" data-textherencia="se eliminaran todas las facturas asociadas" data-ruta="<?php echo e(route('proyecto.destroy', $proyecto->id)); ?>"><i class="fa fa-times"></i></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.page_templates.form_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pages.proyecto.modal_proyecto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pages.proyecto.modal_proyecto_update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
'class' => '',
'elementActive' => 'clientes'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\comercialbcn\resources\views/pages/proyecto/cliente-proyecto.blade.php ENDPATH**/ ?>