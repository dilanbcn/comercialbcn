<div class="wrapper">

    <div class="main-panel">
        @include('layouts.navbars.navs.auth')
        @yield('content')
    </div>
</div>