<form id="frm_validar_reunion" method="POST" style="visibility: hidden;">
    @csrf
</form>