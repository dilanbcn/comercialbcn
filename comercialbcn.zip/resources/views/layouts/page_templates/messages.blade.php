<input type="hidden" id="msg-data" data-estilo="{{ session('estilo') ? session('estilo') : 'success' }}" name="msg-data" data-titulo="{{ session('title') }}" value="{{ session('status') }}">

