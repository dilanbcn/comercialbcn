<form id="frm_del_registro" method="POST" style="visibility: hidden;">
    @method('DELETE')
    @csrf
</form>